package com.phpn.dto.product;

public class ProductResult {
}
