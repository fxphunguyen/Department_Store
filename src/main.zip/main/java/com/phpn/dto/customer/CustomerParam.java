package com.phpn.dto.customer;

public class CustomerParam {
}
