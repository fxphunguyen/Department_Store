package com.phpn.dto.employee;

public class EmployeeParam {
}
