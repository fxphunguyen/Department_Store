package com.phpn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartmentStoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(DepartmentStoreApplication.class, args);
    }

}
