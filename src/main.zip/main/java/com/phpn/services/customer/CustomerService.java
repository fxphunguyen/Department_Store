package com.phpn.services.customer;

public interface CustomerService {
}
