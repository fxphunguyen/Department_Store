package com.phpn.services.employee;

public interface EmployeeService {
}
