package com.phpn.services.product;

public interface ProductService {
}
