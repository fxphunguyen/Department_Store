package com.phpn.services.product;

public class ProductImpl {
}
