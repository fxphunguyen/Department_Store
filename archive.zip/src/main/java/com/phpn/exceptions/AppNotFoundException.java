package com.phpn.exceptions;

public class AppNotFoundException extends Exception {
    public AppNotFoundException(String message) {
        super(message);
    }
}
