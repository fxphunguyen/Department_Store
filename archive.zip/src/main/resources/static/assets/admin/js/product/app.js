class App {
    static DOMAIN_API = "http://localhost:8080";
    static BASE_URL_Product = this.DOMAIN_API + "/api/products";
    static URL_SHOW_PRODUCT_DELETED = this.BASE_URL_Product + "/show_list";
    static URL_CREATE_PRODUCT = this.BASE_URL_Product + "/create";

}