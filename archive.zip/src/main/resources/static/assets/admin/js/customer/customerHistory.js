//model liên hệ
let modalcontact = `
               <div class="MuiBox-root jss797 jss621">
                    <div class="MuiBox-root jss3112 jss3110" style="float: right; margin-top: -58px;">
                        <button id="Sapo-Button-ad916817-bb9e-45bf-9476-d15319352158"
                                class="sc-jqUVSM cdDLAY">
                            <svg class="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24"
                                 aria-hidden="true" style="color: rgb(163, 168, 175); width: 18px;">
                                <path
                                        d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z">
                                </path>
                            </svg>
                            <span class="sc-papXJ fCIlZX">Thêm mới liên hệ</span></button>
                    </div>
                    <div class="MuiPaper-root jss5491 sapo-grid MuiPaper-elevation1 MuiPaper-rounded">
                        <div class="MuiTableContainer-root jss5492 sapo-grid-header-wrapper">
                            <table class="MuiTable-root jss5493 sapo-grid-header" aria-labelledby="tableTitle"
                                   aria-label="enhanced table">
                                <colgroup>
                                    <col style="width: 45px;">
                                    <col style="width: 200px;">
                                    <col style="width: 200px;">
                                    <col style="width: 200px;">
                                    <col style="width: 200px;">
                                    <col style="width: 200px;">
                                </colgroup>
                                <thead class="MuiTableHead-root jss5506">
                                <tr class="MuiTableRow-root MuiTableRow-head">
                                    <th class="MuiTableCell-root MuiTableCell-head jss5515 MuiTableCell-paddingCheckbox"
                                        scope="col"
                                        rowspan="1" style="padding-left: 16px;">
                                        <div class="MuiBox-root jss5536"><span
                                                class="MuiButtonBase-root MuiIconButton-root jss5547 MuiCheckbox-root MuiCheckbox-colorPrimary jss5537 MuiIconButton-colorPrimary"
                                                aria-disabled="false" data-tip="Chọn tất cả liên hệ" currentitem="false"
                                                style="margin: 0px;"><span class="MuiIconButton-label"><input
                                                class="jss5550"
                                                type="checkbox" data-indeterminate="false" value=""><span
                                                class="jss5538"
                                                font-size="small"></span></span><span
                                                class="MuiTouchRipple-root"></span></span></div>
                                    </th>
                                    <th class="MuiTableCell-root MuiTableCell-head jss5510 MuiTableCell-alignLeft"
                                        scope="col"
                                        colspan="1" rowspan="1">Tên liên hệ
                                    </th>
                                    <th class="MuiTableCell-root MuiTableCell-head jss5510 MuiTableCell-alignLeft"
                                        scope="col"
                                        colspan="1" rowspan="1">Số điện thoại
                                    </th>
                                    <th class="MuiTableCell-root MuiTableCell-head jss5510 MuiTableCell-alignLeft"
                                        scope="col"
                                        colspan="1" rowspan="1">Email
                                    </th>
                                    <th class="MuiTableCell-root MuiTableCell-head jss5510 MuiTableCell-alignLeft"
                                        scope="col"
                                        colspan="1" rowspan="1">Chức vụ
                                    </th>
                                    <th class="MuiTableCell-root MuiTableCell-head jss5510 MuiTableCell-alignLeft"
                                        scope="col"
                                        colspan="1" rowspan="1">Bộ phận
                                    </th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <div class="MuiTableContainer-root jss5494 sapo-grid-body-wrapper">
                            <div
                                    style="position: relative; overflow: hidden; width: 100%; height: auto; min-height: 0px; max-height: unset;">
                                <div
                                        style="position: relative; overflow: scroll; margin-right: -17px; margin-bottom: -17px; min-height: 17px;">
                                    <table class="MuiTable-root jss5495 sapo-grid-body" aria-labelledby="tableTitle"
                                           aria-label="enhanced table">
                                        <colgroup>
                                            <col style="width: 45px;">
                                            <col style="width: 200px;">
                                            <col style="width: 200px;">
                                            <col style="width: 200px;">
                                            <col style="width: 200px;">
                                            <col style="width: 200px;">
                                        </colgroup>
                                        <tbody class="MuiTableBody-root">
                                        <tr class="MuiTableRow-root jss5552 MuiTableRow-hover" role="checkbox"
                                            aria-checked="false"
                                            tabindex="-1">
                                            <td class="MuiTableCell-root MuiTableCell-body jss5555 MuiTableCell-paddingCheckbox"
                                                style="padding-left: 16px;"><span
                                                    class="MuiButtonBase-root MuiIconButton-root jss5547 MuiCheckbox-root MuiCheckbox-colorPrimary jss5537 MuiIconButton-colorPrimary"
                                                    aria-disabled="false" style="margin: 0px;"><span
                                                    class="MuiIconButton-label"><input
                                                    class="jss5550" type="checkbox" data-indeterminate="false" value=""><span
                                                    class="jss5538" font-size="small"></span></span><span
                                                    class="MuiTouchRipple-root"></span></span></td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="Acton Alexander" currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    Acton Alexander</p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="03264234"
                                                   currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    03264234</p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="nogomac@mailinator.com" currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    nogomac@mailinator.com</p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="Ea esse magna quibus" currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    Ea esse magna quibus</p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="Assumenda nulla non " currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    Assumenda nulla non </p>
                                            </td>
                                        </tr>
                                        <tr class="MuiTableRow-root jss5552 MuiTableRow-hover" role="checkbox"
                                            aria-checked="false"
                                            tabindex="-1">
                                            <td class="MuiTableCell-root MuiTableCell-body jss5555 MuiTableCell-paddingCheckbox"
                                                style="padding-left: 16px;"><span
                                                    class="MuiButtonBase-root MuiIconButton-root jss5547 MuiCheckbox-root MuiCheckbox-colorPrimary jss5537 MuiIconButton-colorPrimary"
                                                    aria-disabled="false" style="margin: 0px;"><span
                                                    class="MuiIconButton-label"><input
                                                    class="jss5550" type="checkbox" data-indeterminate="false" value=""><span
                                                    class="jss5538" font-size="small"></span></span><span
                                                    class="MuiTouchRipple-root"></span></span></td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="Chase Perkins" currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    Chase Perkins</p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="0388885642" currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    0388885642</p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="jypunos@mailinator.com" currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    jypunos@mailinator.com</p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="Qui ut vero maiores " currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    Qui ut vero maiores </p>
                                            </td>
                                            <td class="MuiTableCell-root MuiTableCell-body jss5558 cellClick MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap"
                                                   data-tip="Occaecat a sit sed " currentitem="false"
                                                   style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                                    Occaecat a sit sed </p>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="jss5497" style="position: fixed; height: 6px; left: 262px;">
                                    <div class="jss5498"
                                         style="position: relative; display: block; height: 100%; width: 0px;"></div>
                                </div>
                                <div style="position: absolute; width: 6px; right: 2px; bottom: 2px; top: 2px; border-radius: 3px;">
                                    <div
                                            style="position: relative; display: block; width: 100%; cursor: pointer; border-radius: inherit; background-color: rgba(0, 0, 0, 0.2); height: 0px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="MuiBox-root jss5567 jss5562 sapo-pagination">
                            <p class="MuiTypography-root MuiTypography-body1">Hiển thị</p>
                            <div class="MuiFormControl-root">
                                <div class="MuiInputBase-root MuiOutlinedInput-root jss5563 MuiInputBase-formControl">
                                    <div
                                            class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input"
                                            tabindex="0" role="button" aria-haspopup="listbox">
                                        <p class="MuiTypography-root jss5565 MuiTypography-body1">20</p>
                                    </div>
                                    <input type="hidden" value="20">
                                    <svg
                                            class="MuiSvgIcon-root MuiSelect-icon MuiSelect-iconOutlined"
                                            focusable="false"
                                            viewBox="0 0 24 24" aria-hidden="true">
                                        <path d="M7 10l5 5 5-5z"></path>
                                    </svg>
                                    <fieldset aria-hidden="true" class="jss5615 MuiOutlinedInput-notchedOutline"
                                              style="padding-left: 8px;">
                                        <legend class="jss5616" style="width: 0.01px;"><span>​</span></legend>
                                    </fieldset>
                                </div>
                            </div>
                            <p class="MuiTypography-root MuiTypography-body1">kết quả</p>
                            <p class="MuiTypography-root jss5564 MuiTypography-body1">Từ 1 đến 2 trên tổng 2</p>
                            <nav aria-label="pagination navigation" class="MuiPagination-root jss5566">
                                <ul class="MuiPagination-ul">
                                    <li>
                                        <button
                                                class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                tabindex="-1" type="button" disabled=""
                                                aria-label="Go to previous page">
                                            <svg
                                                    class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false"
                                                    viewBox="0 0 24 24"
                                                    aria-hidden="true">
                                                <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path>
                                            </svg>
                                        </button>
                                    </li>
                                    <li>
                                        <button
                                                class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-selected MuiPaginationItem-sizeSmall"
                                                tabindex="0" type="button" aria-current="true" aria-label="page 1">
                                            1<span
                                                class="MuiTouchRipple-root"></span></button>
                                    </li>
                                    <li>
                                        <button
                                                class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                tabindex="-1" type="button" disabled="" aria-label="Go to next page">
                                            <svg
                                                    class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false"
                                                    viewBox="0 0 24 24"
                                                    aria-hidden="true">
                                                <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                            </svg>
                                        </button>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div
                                class="__react_component_tooltip t4331f47b-9501-48d7-b3e6-1f46e7a820c7 place-top type-light jss5496"
                                id="t4331f47b-9501-48d7-b3e6-1f46e7a820c7" data-id="tooltip"
                                style="left: 1578px; top: 433px;">
                            <style aria-hidden="true">
                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7 {
                                    color: #222;
                                    background: #fff;
                                    border: 1px solid transparent;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-top {
                                    margin-top: -10px;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-top::before {
                                    border-top: 8px solid transparent;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-top::after {
                                    border-left: 8px solid transparent;
                                    border-right: 8px solid transparent;
                                    bottom: -6px;
                                    left: 50%;
                                    margin-left: -8px;
                                    border-top-color: #fff;
                                    border-top-style: solid;
                                    border-top-width: 6px;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-bottom {
                                    margin-top: 10px;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-bottom::before {
                                    border-bottom: 8px solid transparent;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-bottom::after {
                                    border-left: 8px solid transparent;
                                    border-right: 8px solid transparent;
                                    top: -6px;
                                    left: 50%;
                                    margin-left: -8px;
                                    border-bottom-color: #fff;
                                    border-bottom-style: solid;
                                    border-bottom-width: 6px;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-left {
                                    margin-left: -10px;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-left::before {
                                    border-left: 8px solid transparent;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-left::after {
                                    border-top: 5px solid transparent;
                                    border-bottom: 5px solid transparent;
                                    right: -6px;
                                    top: 50%;
                                    margin-top: -4px;
                                    border-left-color: #fff;
                                    border-left-style: solid;
                                    border-left-width: 6px;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-right {
                                    margin-left: 10px;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-right::before {
                                    border-right: 8px solid transparent;
                                }

                                .t4331f47b-9501-48d7-b3e6-1f46e7a820c7.place-right::after {
                                    border-top: 5px solid transparent;
                                    border-bottom: 5px solid transparent;
                                    left: -6px;
                                    top: 50%;
                                    margin-top: -4px;
                                    border-right-color: #fff;
                                    border-right-style: solid;
                                    border-right-width: 6px;
                                }
                            </style>
                            Assumenda nulla non
                        </div>
                    </div>
                </div>
`

//model địa chỉ
let modalAddress = `   <div class="MuiBox-root jss797 jss621">
              <div class="MuiBox-root jss5983 jss5981">
              <button id="btn_showModalCreateAddress" class="btn_showModalCreateAddress sc-jqUVSM cdDLAY" style="float: right; margin-top: -58px"><svg class="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true" style="color: rgb(163, 168, 175); width: 18px;">
                    <path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z">
                    </path>
                  </svg><span class="sc-papXJ fCIlZX">Thêm mới địa chỉ</span></button></div>
              <div class="MuiBox-root jss5998 jss5978">
                <div class="MuiPaper-root jss6031 sapo-grid MuiPaper-elevation1 MuiPaper-rounded">
                  <div class="MuiTableContainer-root jss6032 sapo-grid-header-wrapper">
                    <table class="MuiTable-root jss6033 sapo-grid-header" aria-labelledby="tableTitle" aria-label="enhanced table">
                      <colgroup>
                        <col style="width: 45px;">
                        <col style="width: 167px;">
                        <col style="width: 207px;">
                        <col style="width: 167px;">
                        <col style="width: 167px;">
                        <col style="width: 167px;">
                        <col style="width: 167px;">
                        <col style="width: 167px;">
                      </colgroup>
                      <thead class="MuiTableHead-root jss6046">
                        <tr class="MuiTableRow-root MuiTableRow-head">
                          <th class="MuiTableCell-root MuiTableCell-head jss6055 MuiTableCell-paddingCheckbox" scope="col" rowspan="1" style="padding-left: 16px;">
                            <div class="MuiBox-root jss6076"><span class="MuiButtonBase-root MuiIconButton-root jss6087 MuiCheckbox-root MuiCheckbox-colorPrimary jss6077 MuiIconButton-colorPrimary" aria-disabled="false" data-tip="Chọn tất cả địa chỉ" currentitem="false" style="margin: 0px;"><span class="MuiIconButton-label"><input class="jss6090" type="checkbox" data-indeterminate="false" value=""><span class="jss6078" font-size="small"></span></span><span class="MuiTouchRipple-root"></span></span>
                            </div>
                          </th>
                          <th class="MuiTableCell-root MuiTableCell-head jss6050 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Số điện thoại</th>
                          <th class="MuiTableCell-root MuiTableCell-head jss6050 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Địa chỉ</th>
                          <th class="MuiTableCell-root MuiTableCell-head jss6050 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Phường xã</th>
                          <th class="MuiTableCell-root MuiTableCell-head jss6050 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Quận huyện</th>
                          <th class="MuiTableCell-root MuiTableCell-head jss6050 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Tỉnh thành phố</th>
                          <th class="MuiTableCell-root MuiTableCell-head jss6050 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Mã bưu điện</th>
                          <th class="MuiTableCell-root MuiTableCell-head jss6050 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Email</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
                  <div class="MuiTableContainer-root jss6034 sapo-grid-body-wrapper">
                    <div style="position: relative; overflow: hidden; width: 100%; height: auto; min-height: 0px; max-height: unset;">
                      <div style="position: relative; overflow: scroll; margin-right: -17px; margin-bottom: -17px; min-height: 17px;">
                        <table class="MuiTable-root jss6035 sapo-grid-body" aria-labelledby="tableTitle" aria-label="enhanced table">
                          <colgroup>
                            <col style="width: 45px;">
                            <col style="width: 167px;">
                            <col style="width: 207px;">
                            <col style="width: 167px;">
                            <col style="width: 167px;">
                            <col style="width: 167px;">
                            <col style="width: 167px;">
                            <col style="width: 167px;">
                          </colgroup>
                          <tbody class="MuiTableBody-root showShippingAddress">
                            <tr class="MuiTableRow-root jss6092 MuiTableRow-hover" role="checkbox" aria-checked="false" tabindex="-1">
                              <td class="MuiTableCell-root MuiTableCell-body jss6095 MuiTableCell-paddingCheckbox" style="padding-left: 16px;"><span class="MuiButtonBase-root MuiIconButton-root jss6087 MuiCheckbox-root MuiCheckbox-colorPrimary jss6077 MuiIconButton-colorPrimary" aria-disabled="false" style="margin: 0px;"><span class="MuiIconButton-label"><input class="jss6090" type="checkbox" data-indeterminate="false" value=""><span class="jss6078" font-size="small"></span></span><span class="MuiTouchRipple-root"></span></span></td>
                              <td class="MuiTableCell-root MuiTableCell-body jss6098 cellClick MuiTableCell-alignLeft">
                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap" data-tip="09876543255" currentitem="false" style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                  09876543255</p>
                              </td>
                              <td class="MuiTableCell-root MuiTableCell-body jss6098 MuiTableCell-alignLeft">
                                <div style="cursor: pointer;">Earum in nostrum cul</div>
                              </td>
                              <td class="MuiTableCell-root MuiTableCell-body jss6098 MuiTableCell-alignLeft">
                                <div style="cursor: pointer;"></div>
                              </td>
                              <td class="MuiTableCell-root MuiTableCell-body jss6098 MuiTableCell-alignLeft">
                                <div style="cursor: pointer;"></div>
                              </td>
                              <td class="MuiTableCell-root MuiTableCell-body jss6098 cellClick MuiTableCell-alignLeft">
                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap" data-tip="" currentitem="false" style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                </p>
                              </td>
                              <td class="MuiTableCell-root MuiTableCell-body jss6098 cellClick MuiTableCell-alignLeft">
                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap" data-tip="" currentitem="false" style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                </p>
                              </td>
                              <td class="MuiTableCell-root MuiTableCell-body jss6098 cellClick MuiTableCell-alignLeft">
                                <p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap" data-tip="" currentitem="false" style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">
                                </p>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div class="jss6037" style="position: fixed; height: 6px; left: 262px;">
                        <div class="jss6038" style="position: relative; display: block; height: 100%; width: 0px;">
                        </div>
                      </div>
                      <div style="position: absolute; width: 6px; right: 2px; bottom: 2px; top: 2px; border-radius: 3px;">
                        <div style="position: relative; display: block; width: 100%; cursor: pointer; border-radius: inherit; background-color: rgba(0, 0, 0, 0.2); height: 0px;">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="MuiBox-root jss6107 jss6102 sapo-pagination">
                    <p class="MuiTypography-root MuiTypography-body1">Hiển thị</p>
                    <div class="MuiFormControl-root">
                      <div class="MuiInputBase-root MuiOutlinedInput-root jss6103 MuiInputBase-formControl">
                        <div class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input" tabindex="0" role="button" aria-haspopup="listbox">
                          <p class="MuiTypography-root jss6105 MuiTypography-body1">20</p>
                        </div><input type="hidden" value="20"><svg class="MuiSvgIcon-root MuiSelect-icon MuiSelect-iconOutlined" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
                          <path d="M7 10l5 5 5-5z"></path>
                        </svg>
                        <fieldset aria-hidden="true" class="jss6155 MuiOutlinedInput-notchedOutline" style="padding-left: 8px;">
                          <legend class="jss6156" style="width: 0.01px;"><span>​</span></legend>
                        </fieldset>
                      </div>
                    </div>
                    <p class="MuiTypography-root MuiTypography-body1">kết quả</p>
                    <p class="MuiTypography-root jss6104 MuiTypography-body1">Từ 1 đến 1 trên tổng 1</p>
                    <nav aria-label="pagination navigation" class="MuiPagination-root jss6106">
                      <ul class="MuiPagination-ul">
                        <li><button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled" tabindex="-1" type="button" disabled="" aria-label="Go to previous page"><svg class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
                              <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path>
                            </svg></button></li>
                        <li><button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-selected MuiPaginationItem-sizeSmall" tabindex="0" type="button" aria-current="true" aria-label="page 1">1<span class="MuiTouchRipple-root"></span></button></li>
                        <li><button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled" tabindex="-1" type="button" disabled="" aria-label="Go to next page"><svg class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></button></li>
                      </ul>
                    </nav>
                  </div>
                  <div class="__react_component_tooltip t8815cdda-f529-4dbe-b100-43436766531c place-top type-dark" id="t8815cdda-f529-4dbe-b100-43436766531c" data-id="tooltip">
                    <style aria-hidden="true">
                      .t8815cdda-f529-4dbe-b100-43436766531c {
                        color: #fff;
                        background: #222;
                        border: 1px solid transparent;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-top {
                        margin-top: -10px;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-top::before {
                        border-top: 8px solid transparent;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-top::after {
                        border-left: 8px solid transparent;
                        border-right: 8px solid transparent;
                        bottom: -6px;
                        left: 50%;
                        margin-left: -8px;
                        border-top-color: #222;
                        border-top-style: solid;
                        border-top-width: 6px;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-bottom {
                        margin-top: 10px;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-bottom::before {
                        border-bottom: 8px solid transparent;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-bottom::after {
                        border-left: 8px solid transparent;
                        border-right: 8px solid transparent;
                        top: -6px;
                        left: 50%;
                        margin-left: -8px;
                        border-bottom-color: #222;
                        border-bottom-style: solid;
                        border-bottom-width: 6px;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-left {
                        margin-left: -10px;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-left::before {
                        border-left: 8px solid transparent;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-left::after {
                        border-top: 5px solid transparent;
                        border-bottom: 5px solid transparent;
                        right: -6px;
                        top: 50%;
                        margin-top: -4px;
                        border-left-color: #222;
                        border-left-style: solid;
                        border-left-width: 6px;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-right {
                        margin-left: 10px;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-right::before {
                        border-right: 8px solid transparent;
                      }

                      .t8815cdda-f529-4dbe-b100-43436766531c.place-right::after {
                        border-top: 5px solid transparent;
                        border-bottom: 5px solid transparent;
                        left: -6px;
                        top: 50%;
                        margin-top: -4px;
                        border-right-color: #222;
                        border-right-style: solid;
                        border-right-width: 6px;
                      }
                    </style>
                  </div>
                </div>
              </div>
            </div>
`
let modalCongNo = ` <div class="MuiBox-root jss828 jss820">
                        <div class="MuiPaper-root jss864 sapo-grid MuiPaper-elevation1 MuiPaper-rounded">
                            <div class="MuiTableContainer-root jss865 sapo-grid-header-wrapper">
                                <table class="MuiTable-root jss866 sapo-grid-header" aria-labelledby="tableTitle"
                                       aria-label="enhanced table">
                                    
                                    <thead class="MuiTableHead-root jss879">
                                    <tr class="MuiTableRow-root MuiTableRow-head">
                                        <th class="MuiTableCell-root MuiTableCell-head jss883 MuiTableCell-alignLeft"
                                            scope="col" colspan="1" rowspan="1">Mã phiếu
                                        </th>
                                        <th class="MuiTableCell-root MuiTableCell-head jss883 MuiTableCell-alignLeft"
                                            scope="col" colspan="1" rowspan="1">Người tạo
                                        </th>
                                        <th class="MuiTableCell-root MuiTableCell-head jss883 MuiTableCell-alignLeft"
                                            scope="col" colspan="1" rowspan="1">Ngày tạo
                                        </th>
                                        <th class="MuiTableCell-root MuiTableCell-head jss883 MuiTableCell-alignLeft"
                                            scope="col" colspan="1" rowspan="1">Ngày ghi nhận
                                        </th>
                                        <th class="MuiTableCell-root MuiTableCell-head jss883 MuiTableCell-alignLeft"
                                            scope="col" colspan="1" rowspan="1">Ghi chú
                                        </th>
                                        <th class="MuiTableCell-root MuiTableCell-head jss883 MuiTableCell-alignRight"
                                            scope="col" colspan="1" rowspan="1">Giá trị thay đổi
                                        </th>
                                        <th class="MuiTableCell-root MuiTableCell-head jss883 MuiTableCell-alignRight"
                                            scope="col" colspan="1" rowspan="1">Công nợ
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody class="MuiTableBody-root showCustomerDebtById" >
                                    </tbody>
                                     </table>
                                    </div>
                                    <div class="jss870" style="position: fixed; height: 6px; left: 262px;">
                                        <div class="jss871"
                                             style="position: relative; display: block; height: 100%; width: 0px;"></div>
                                    </div>
                                    <div style="position: absolute; width: 6px; right: 2px; bottom: 2px; top: 2px; border-radius: 3px;">
                                        <div style="position: relative; display: block; width: 100%; cursor: pointer; border-radius: inherit; background-color: rgba(0, 0, 0, 0.2); height: 0px;"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="MuiBox-root jss926 jss921 sapo-pagination">
                            <p
                                    class="MuiTypography-root MuiTypography-body1">Hiển thị</p>
                                <div class="MuiFormControl-root">
                                    <div class="MuiInputBase-root MuiOutlinedInput-root jss922 MuiInputBase-formControl">
                                        <div class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input"
                                             tabindex="0" role="button" aria-haspopup="listbox"><p
                                                class="MuiTypography-root jss924 MuiTypography-body1">20</p></div>
                                        <input type="hidden" value="20">
                                        <svg class="MuiSvgIcon-root MuiSelect-icon MuiSelect-iconOutlined"
                                             focusable="false" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M7 10l5 5 5-5z"></path>
                                        </svg>
                                        <fieldset aria-hidden="true" class="jss974 MuiOutlinedInput-notchedOutline"
                                                  style="padding-left: 8px;">
                                            <legend class="jss975" style="width: 0.01px;"><span>​</span></legend>
                                        </fieldset>
                                    </div>
                                </div>
                                <p class="MuiTypography-root MuiTypography-body1">kết quả</p>
                                <p class="MuiTypography-root jss923 MuiTypography-body1">Từ 1 đến 6 trên tổng 6</p>
                                <nav aria-label="pagination navigation" class="MuiPagination-root jss925">
                                    <ul class="MuiPagination-ul">
                                        <li>
                                            <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                    tabindex="-1" type="button" disabled=""
                                                    aria-label="Go to previous page">
                                                <svg class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false"
                                                     viewBox="0 0 24 24" aria-hidden="true">
                                                    <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path>
                                                </svg>
                                            </button>
                                        </li>
                                        <li>
                                            <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-selected MuiPaginationItem-sizeSmall"
                                                    tabindex="0" type="button" aria-current="true" aria-label="page 1">1<span
                                                    class="MuiTouchRipple-root"></span></button>
                                        </li>
                                        <li>
                                            <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                    tabindex="-1" type="button" disabled=""
                                                    aria-label="Go to next page">
                                                <svg class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false"
                                                     viewBox="0 0 24 24" aria-hidden="true">
                                                    <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                </svg>
                                            </button>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <div class="__react_component_tooltip t2da217e8-d449-422f-87bd-f9f06ca64ad0 place-top type-light jss869"
                                 id="t2da217e8-d449-422f-87bd-f9f06ca64ad0" data-id="tooltip"
                                 style="left: 509px; top: 465px;">
                                <style aria-hidden="true">
                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0 {
                                        color: #222;
                                        background: #fff;
                                        border: 1px solid transparent;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-top {
                                        margin-top: -10px;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-top::before {
                                        border-top: 8px solid transparent;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-top::after {
                                        border-left: 8px solid transparent;
                                        border-right: 8px solid transparent;
                                        bottom: -6px;
                                        left: 50%;
                                        margin-left: -8px;
                                        border-top-color: #fff;
                                        border-top-style: solid;
                                        border-top-width: 6px;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-bottom {
                                        margin-top: 10px;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-bottom::before {
                                        border-bottom: 8px solid transparent;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-bottom::after {
                                        border-left: 8px solid transparent;
                                        border-right: 8px solid transparent;
                                        top: -6px;
                                        left: 50%;
                                        margin-left: -8px;
                                        border-bottom-color: #fff;
                                        border-bottom-style: solid;
                                        border-bottom-width: 6px;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-left {
                                        margin-left: -10px;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-left::before {
                                        border-left: 8px solid transparent;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-left::after {
                                        border-top: 5px solid transparent;
                                        border-bottom: 5px solid transparent;
                                        right: -6px;
                                        top: 50%;
                                        margin-top: -4px;
                                        border-left-color: #fff;
                                        border-left-style: solid;
                                        border-left-width: 6px;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-right {
                                        margin-left: 10px;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-right::before {
                                        border-right: 8px solid transparent;
                                    }

                                    .t2da217e8-d449-422f-87bd-f9f06ca64ad0.place-right::after {
                                        border-top: 5px solid transparent;
                                        border-bottom: 5px solid transparent;
                                        left: -6px;
                                        top: 50%;
                                        margin-top: -4px;
                                        border-right-color: #fff;
                                        border-right-style: solid;
                                        border-right-width: 6px;
                                    }
                                </style>
                                
                            </div>
                        </div>
                    </div>`
let modalHistoryOrder = `
                        <div class="MuiBox-root jss817 jss641">
                        <div class="MuiBox-root jss1378 jss1375">
                            <div class="MuiPaper-root jss1381 sapo-grid MuiPaper-elevation1 MuiPaper-rounded">
                                <div class="MuiTableContainer-root jss1382 sapo-grid-header-wrapper">
                                    <table id="tableHistoryCustomerOrder" class="MuiTable-root jss1383 sapo-grid-header" aria-labelledby="tableTitle"
                                           aria-label="enhanced table">
                                        <thead class="MuiTableHead-root jss1396">
                                        <tr class="MuiTableRow-root MuiTableRow-head">
                                            <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Mã đơn hàng
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Trạng thái
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignRight"
                                                scope="col" colspan="1" rowspan="1" style="width: 200px ;text-align: end; color: black;">Giá trị
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Chi nhánh
                                            </th>
                                              <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Thanh toán
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Nguồn đơn
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Nhân viên xử lý đơn
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss1400 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Ngày ghi nhận
                                            </th>
                                        </tr>
                                        </thead>
                                                <tbody class="MuiTableBody-root showAllCustomerOrderHistory">
                                                </tbody>
                                    </table>
                                        </div>
                                        <div class="jss1387" style="position: fixed; height: 6px; left: 262px;">
                                            <div class="jss1388"
                                                 style="position: relative; display: block; height: 100%; width: 0px;"></div>
                                        </div>
                                        <div style="position: absolute; width: 6px; right: 2px; bottom: 2px; top: 2px; border-radius: 3px;">
                                            <div style="position: relative; display: block; width: 100%; cursor: pointer; border-radius: inherit; background-color: rgba(0, 0, 0, 0.2); height: 0px;"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="MuiBox-root jss1443 jss1438 sapo-pagination"><p
                                        class="MuiTypography-root MuiTypography-body1">Hiển thị</p>
                                    <div class="MuiFormControl-root">
                                        <div class="MuiInputBase-root MuiOutlinedInput-root jss1439 MuiInputBase-formControl">
                                            <div class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input"
                                                 tabindex="0" role="button" aria-haspopup="listbox"><p
                                                    class="MuiTypography-root jss1441 MuiTypography-body1">20</p></div>
                                            <input type="hidden" value="20">
                                            <svg class="MuiSvgIcon-root MuiSelect-icon MuiSelect-iconOutlined"
                                                 focusable="false" viewBox="0 0 24 24" aria-hidden="true">
                                                <path d="M7 10l5 5 5-5z"></path>
                                            </svg>
                                            <fieldset aria-hidden="true" class="jss1491 MuiOutlinedInput-notchedOutline"
                                                      style="padding-left: 8px;">
                                                <legend class="jss1492" style="width: 0.01px;"><span>​</span></legend>
                                            </fieldset>
                                        </div>
                                    </div>
                                    <p class="MuiTypography-root MuiTypography-body1">kết quả</p>
                                    <p class="MuiTypography-root jss1440 MuiTypography-body1">Từ 1 đến 3 trên tổng 3</p>
                                    <nav aria-label="pagination navigation" class="MuiPagination-root jss1442">
                                        <ul class="MuiPagination-ul">
                                            <li>
                                                <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                        tabindex="-1" type="button" disabled=""
                                                        aria-label="Go to previous page">
                                                    <svg class="MuiSvgIcon-root MuiPaginationItem-icon"
                                                         focusable="false" viewBox="0 0 24 24" aria-hidden="true">
                                                        <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path>
                                                    </svg>
                                                </button>
                                            </li>
                                            <li>
                                                <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-selected MuiPaginationItem-sizeSmall"
                                                        tabindex="0" type="button" aria-current="true"
                                                        aria-label="page 1">1<span class="MuiTouchRipple-root"></span>
                                                </button>
                                            </li>
                                            <li>
                                                <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                        tabindex="-1" type="button" disabled=""
                                                        aria-label="Go to next page">
                                                    <svg class="MuiSvgIcon-root MuiPaginationItem-icon"
                                                         focusable="false" viewBox="0 0 24 24" aria-hidden="true">
                                                        <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                    </svg>
                                                </button>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                <div class="__react_component_tooltip t9eb02321-a174-4d68-9524-2454badafbce place-top type-dark"
                                     id="t9eb02321-a174-4d68-9524-2454badafbce" data-id="tooltip">
                                    <style aria-hidden="true">
                                        .t9eb02321-a174-4d68-9524-2454badafbce {
                                            color: #fff;
                                            background: #222;
                                            border: 1px solid transparent;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-top {
                                            margin-top: -10px;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-top::before {
                                            border-top: 8px solid transparent;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-top::after {
                                            border-left: 8px solid transparent;
                                            border-right: 8px solid transparent;
                                            bottom: -6px;
                                            left: 50%;
                                            margin-left: -8px;
                                            border-top-color: #222;
                                            border-top-style: solid;
                                            border-top-width: 6px;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-bottom {
                                            margin-top: 10px;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-bottom::before {
                                            border-bottom: 8px solid transparent;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-bottom::after {
                                            border-left: 8px solid transparent;
                                            border-right: 8px solid transparent;
                                            top: -6px;
                                            left: 50%;
                                            margin-left: -8px;
                                            border-bottom-color: #222;
                                            border-bottom-style: solid;
                                            border-bottom-width: 6px;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-left {
                                            margin-left: -10px;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-left::before {
                                            border-left: 8px solid transparent;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-left::after {
                                            border-top: 5px solid transparent;
                                            border-bottom: 5px solid transparent;
                                            right: -6px;
                                            top: 50%;
                                            margin-top: -4px;
                                            border-left-color: #222;
                                            border-left-style: solid;
                                            border-left-width: 6px;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-right {
                                            margin-left: 10px;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-right::before {
                                            border-right: 8px solid transparent;
                                        }

                                        .t9eb02321-a174-4d68-9524-2454badafbce.place-right::after {
                                            border-top: 5px solid transparent;
                                            border-bottom: 5px solid transparent;
                                            left: -6px;
                                            top: 50%;
                                            margin-top: -4px;
                                            border-right-color: #222;
                                            border-right-style: solid;
                                            border-right-width: 6px;
                                        }
                                    </style>
                                </div>
                            </div>
                        </div>
                    </div>

    `

let noModalNote = `
                        <div class="MuiBox-root jss817 jss641">
                        <div class="MuiBox-root jss3560 jss3558">
                            <button id="Sapo-Button-fb87e2dd-7d9d-4775-b5d8-b40cf52e2756" class="sc-jqUVSM cdDLAY">
                                <svg class="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"
                                     style="color: rgb(163, 168, 175); width: 18px;">
                                    <path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"></path>
                                </svg>
                                <span class="sc-papXJ fCIlZX">Thêm mới ghi chú</span></button>
                        </div>
                        <form action="#"></form>
                        <div class="MuiBox-root jss3609"><p
                                class="MuiTypography-root MuiTypography-body1 MuiTypography-colorSecondary">Không có dữ
                            liệu ghi chú</p></div>
                    </div>
    `;

let modalNote = `
                    <div class="MuiPaper-root jss22054 sapo-grid MuiPaper-elevation1 MuiPaper-rounded"><div class="MuiTableContainer-root jss22055 sapo-grid-header-wrapper"><table class="MuiTable-root jss22056 sapo-grid-header" aria-labelledby="tableTitle" aria-label="enhanced table"><colgroup><col style="width: 45px;"><col style="width: 297px;"><col style="width: 251px;"><col style="width: 207px;"></colgroup><thead class="MuiTableHead-root jss22069"><tr class="MuiTableRow-root MuiTableRow-head"><th class="MuiTableCell-root MuiTableCell-head jss22078 MuiTableCell-paddingCheckbox" scope="col" rowspan="1" style="padding-left: 16px;"><div class="MuiBox-root jss22099"><span class="MuiButtonBase-root MuiIconButton-root jss22110 MuiCheckbox-root MuiCheckbox-colorPrimary jss22100 MuiIconButton-colorPrimary" aria-disabled="false" data-tip="Chọn tất cả ghi chú" currentitem="false" style="margin: 0px;"><span class="MuiIconButton-label"><input class="jss22113" type="checkbox" data-indeterminate="false" value=""><span class="jss22101" font-size="small"></span></span><span class="MuiTouchRipple-root"></span></span></div></th><th class="MuiTableCell-root MuiTableCell-head jss22073 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Ghi chú</th><th class="MuiTableCell-root MuiTableCell-head jss22073 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Người thêm</th><th class="MuiTableCell-root MuiTableCell-head jss22073 MuiTableCell-alignLeft" scope="col" colspan="1" rowspan="1">Thời gian</th></tr></thead></table></div><div class="MuiTableContainer-root jss22057 sapo-grid-body-wrapper"><div style="position: relative; overflow: hidden; width: 100%; height: auto; min-height: 0px; max-height: unset;"><div style="position: relative; overflow: scroll; margin-right: -17px; margin-bottom: -17px; min-height: 17px;"><table class="MuiTable-root jss22058 sapo-grid-body" aria-labelledby="tableTitle" aria-label="enhanced table"><colgroup><col style="width: 45px;"><col style="width: 297px;"><col style="width: 251px;"><col style="width: 207px;"></colgroup><tbody class="MuiTableBody-root"><tr class="MuiTableRow-root jss22115 MuiTableRow-hover" role="checkbox" aria-checked="false" tabindex="-1"><td class="MuiTableCell-root MuiTableCell-body jss22118 MuiTableCell-paddingCheckbox" style="padding-left: 16px;"><span class="MuiButtonBase-root MuiIconButton-root jss22110 MuiCheckbox-root MuiCheckbox-colorPrimary jss22100 MuiIconButton-colorPrimary" aria-disabled="false" style="margin: 0px;"><span class="MuiIconButton-label"><input class="jss22113" type="checkbox" data-indeterminate="false" value=""><span class="jss22101" font-size="small"></span></span><span class="MuiTouchRipple-root"></span></span></td><td class="MuiTableCell-root MuiTableCell-body jss22121 cellClick MuiTableCell-alignLeft"><p class="MuiTypography-root MuiTypography-body1 MuiTypography-noWrap" data-tip="sss" currentitem="false" style="width: fit-content; max-width: 100%; display: inline-block; vertical-align: middle;">sss</p></td><td class="MuiTableCell-root MuiTableCell-body jss22121 MuiTableCell-alignLeft"><div class="MuiBox-root jss22125" style="cursor: pointer;">Nguyễn Đình Quốc Huy</div></td><td class="MuiTableCell-root MuiTableCell-body jss22121 MuiTableCell-alignLeft"><div class="MuiBox-root jss22126" style="cursor: pointer;">05-12-2022 12:39</div></td></tr></tbody></table></div><div class="jss22060" style="position: fixed; height: 6px; left: 262px;"><div class="jss22061" style="position: relative; display: block; height: 100%; width: 0px;"></div></div><div style="position: absolute; width: 6px; right: 2px; bottom: 2px; top: 2px; border-radius: 3px;"><div style="position: relative; display: block; width: 100%; cursor: pointer; border-radius: inherit; background-color: rgba(0, 0, 0, 0.2); height: 0px;"></div></div></div></div><div class="MuiBox-root jss22132 jss22127 sapo-pagination"><p class="MuiTypography-root MuiTypography-body1">Hiển thị</p><div class="MuiFormControl-root"><div class="MuiInputBase-root MuiOutlinedInput-root jss22128 MuiInputBase-formControl"><div class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input" tabindex="0" role="button" aria-haspopup="listbox"><p class="MuiTypography-root jss22130 MuiTypography-body1">20</p></div><input type="hidden" value="20"><svg class="MuiSvgIcon-root MuiSelect-icon MuiSelect-iconOutlined" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10l5 5 5-5z"></path></svg><fieldset aria-hidden="true" class="jss21538 MuiOutlinedInput-notchedOutline" style="padding-left: 8px;"><legend class="jss21539" style="width: 0.01px;"><span>​</span></legend></fieldset></div></div><p class="MuiTypography-root MuiTypography-body1">kết quả</p><p class="MuiTypography-root jss22129 MuiTypography-body1">Từ 1 đến 1 trên tổng 1</p><nav aria-label="pagination navigation" class="MuiPagination-root jss22131"><ul class="MuiPagination-ul"><li><button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled" tabindex="-1" type="button" disabled="" aria-label="Go to previous page"><svg class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></svg></button></li><li><button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-selected MuiPaginationItem-sizeSmall" tabindex="0" type="button" aria-current="true" aria-label="page 1">1<span class="MuiTouchRipple-root"></span></button></li><li><button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled" tabindex="-1" type="button" disabled="" aria-label="Go to next page"><svg class="MuiSvgIcon-root MuiPaginationItem-icon" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></svg></button></li></ul></nav></div><div class="__react_component_tooltip tb680b5d8-75fa-4bd1-8da8-c1e0942cab02 place-top type-light jss22059" id="tb680b5d8-75fa-4bd1-8da8-c1e0942cab02" data-id="tooltip" style="left: 361px; top: 662px;"><style aria-hidden="true">
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02 {
                            color: #222;
                            background: #fff;
                            border: 1px solid transparent;
                        }

                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-top {
                            margin-top: -10px;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-top::before {
                            border-top: 8px solid transparent;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-top::after {
                            border-left: 8px solid transparent;
                            border-right: 8px solid transparent;
                            bottom: -6px;
                            left: 50%;
                            margin-left: -8px;
                            border-top-color: #fff;
                            border-top-style: solid;
                            border-top-width: 6px;
                        }

                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-bottom {
                            margin-top: 10px;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-bottom::before {
                            border-bottom: 8px solid transparent;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-bottom::after {
                            border-left: 8px solid transparent;
                            border-right: 8px solid transparent;
                            top: -6px;
                            left: 50%;
                            margin-left: -8px;
                            border-bottom-color: #fff;
                            border-bottom-style: solid;
                            border-bottom-width: 6px;
                        }

                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-left {
                            margin-left: -10px;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-left::before {
                            border-left: 8px solid transparent;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-left::after {
                            border-top: 5px solid transparent;
                            border-bottom: 5px solid transparent;
                            right: -6px;
                            top: 50%;
                            margin-top: -4px;
                            border-left-color: #fff;
                            border-left-style: solid;
                            border-left-width: 6px;
                        }

                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-right {
                            margin-left: 10px;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-right::before {
                            border-right: 8px solid transparent;
                        }
                        .tb680b5d8-75fa-4bd1-8da8-c1e0942cab02.place-right::after {
                            border-top: 5px solid transparent;
                            border-bottom: 5px solid transparent;
                            left: -6px;
                            top: 50%;
                            margin-top: -4px;
                            border-right-color: #fff;
                            border-right-style: solid;
                            border-right-width: 6px;
                        }
                    </style>sss</div></div>

`
let modalCustomerGroup = `
                        <div class="MuiBox-root jss817 jss641">
                        <div class="MuiBox-root jss3895 jss3892">
                            <div class="MuiPaper-root jss3899 sapo-grid MuiPaper-elevation1 MuiPaper-rounded">
                                <div class="MuiTableContainer-root jss3900 sapo-grid-header-wrapper">
                                    <table class="MuiTable-root jss3901 sapo-grid-header" aria-labelledby="tableTitle"
                                           aria-label="enhanced table">
                                        <colgroup>
                                            <col style="width: 105px;">
                                            <col style="width: 287px;">
                                            <col style="width: 181px;">
                                            <col style="width: 219px;">
                                        </colgroup>
                                        <thead class="MuiTableHead-root jss3914">
                                        <tr class="MuiTableRow-root MuiTableRow-head">
                                            <th class="MuiTableCell-root MuiTableCell-head jss3918 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Mã nhóm
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss3918 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Tên nhóm
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss3918 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Loại nhóm
                                            </th>
                                            <th class="MuiTableCell-root MuiTableCell-head jss3918 MuiTableCell-alignLeft"
                                                scope="col" colspan="1" rowspan="1">Mô tả
                                            </th>
                                        </tr>
                                        </thead>
                                    </table>
                                </div>
                                <div class="MuiTableContainer-root jss3902 sapo-grid-body-wrapper">
                                    <div style="position: relative; overflow: hidden; width: 100%; height: auto; min-height: 0px; max-height: unset;">
                                        <div style="position: relative; overflow: scroll; margin-right: -17px; margin-bottom: -17px; min-height: 17px;">
                                            <table class="MuiTable-root jss3903 sapo-grid-body"
                                                   aria-labelledby="tableTitle" aria-label="enhanced table">
                                                <colgroup>
                                                    <col style="width: 105px;">
                                                    <col style="width: 287px;">
                                                    <col style="width: 181px;">
                                                    <col style="width: 219px;">
                                                </colgroup>
                                                <tbody class="MuiTableBody-root">
                                                <tr class="MuiTableRow-root jss3945 MuiTableRow-hover" role="checkbox"
                                                    tabindex="-1">
                                                    <td class="MuiTableCell-root MuiTableCell-body jss3951 MuiTableCell-alignLeft">
                                                        <a class="jss3955"
                                                           href="/admin/customer_groups/2607991">Add</a></td>
                                                    <td class="MuiTableCell-root MuiTableCell-body jss3951 MuiTableCell-alignLeft">
                                                        <p class="MuiTypography-root MuiTypography-body1"
                                                           title="t.customerGroupValidate.name">Ten nhom</p></td>
                                                    <td class="MuiTableCell-root MuiTableCell-body jss3951 MuiTableCell-alignLeft">
                                                        <p class="MuiTypography-root MuiTypography-body1"
                                                           title="t.customerGroupValidate.groupType">Cố định</p></td>
                                                    <td class="MuiTableCell-root MuiTableCell-body jss3951 MuiTableCell-alignLeft">
                                                        <p class="MuiTypography-root MuiTypography-body1"
                                                           title="t.customerGroupValidate.note"><span>---</span></p>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>

                                <p class="MuiTypography-root MuiTypography-body1"></p>
                                <p class="MuiTypography-root jss3958 MuiTypography-body1"></p>
                                <nav aria-label="pagination navigation" class="MuiPagination-root jss3960">
                                    <ul class="MuiPagination-ul">
                                        <li>
                                            <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                    tabindex="-1" type="button" disabled=""
                                                    aria-label="Go to previous page">
                                            </button>
                                        </li>
                                        <li>

                                        </li>
                                        <li>
                                            <button class="MuiButtonBase-root MuiPaginationItem-root MuiPaginationItem-page MuiPaginationItem-textPrimary Mui-disabled MuiPaginationItem-sizeSmall Mui-disabled"
                                                    tabindex="-1" type="button" disabled=""
                                                    aria-label="Go to next page">

                                            </button>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <div class="__react_component_tooltip t7cff1fe5-4473-40cf-902e-c620e19d37fe place-top type-dark"
                                 id="t7cff1fe5-4473-40cf-902e-c620e19d37fe" data-id="tooltip">
                                <style aria-hidden="true">
                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe {
                                        color: #fff;
                                        background: #222;
                                        border: 1px solid transparent;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-top {
                                        margin-top: -10px;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-top::before {
                                        border-top: 8px solid transparent;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-top::after {
                                        border-left: 8px solid transparent;
                                        border-right: 8px solid transparent;
                                        bottom: -6px;
                                        left: 50%;
                                        margin-left: -8px;
                                        border-top-color: #222;
                                        border-top-style: solid;
                                        border-top-width: 6px;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-bottom {
                                        margin-top: 10px;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-bottom::before {
                                        border-bottom: 8px solid transparent;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-bottom::after {
                                        border-left: 8px solid transparent;
                                        border-right: 8px solid transparent;
                                        top: -6px;
                                        left: 50%;
                                        margin-left: -8px;
                                        border-bottom-color: #222;
                                        border-bottom-style: solid;
                                        border-bottom-width: 6px;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-left {
                                        margin-left: -10px;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-left::before {
                                        border-left: 8px solid transparent;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-left::after {
                                        border-top: 5px solid transparent;
                                        border-bottom: 5px solid transparent;
                                        right: -6px;
                                        top: 50%;
                                        margin-top: -4px;
                                        border-left-color: #222;
                                        border-left-style: solid;
                                        border-left-width: 6px;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-right {
                                        margin-left: 10px;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-right::before {
                                        border-right: 8px solid transparent;
                                    }

                                    .t7cff1fe5-4473-40cf-902e-c620e19d37fe.place-right::after {
                                        border-top: 5px solid transparent;
                                        border-bottom: 5px solid transparent;
                                        left: -6px;
                                        top: 50%;
                                        margin-top: -4px;
                                        border-right-color: #222;
                                        border-right-style: solid;
                                        border-right-width: 6px;
                                    }
                                </style>
                            </div>
                        </div>
                    </div>
    `

let noModalHistoryOrder = `
              <div class="MuiBox-root jss13030 jss12854">
                <div class="MuiBox-root jss13034 jss13031">
                    <div class="MuiBox-root jss13047"><p
                            class="MuiTypography-root MuiTypography-body1 MuiTypography-colorSecondary" style="margin-top: 20px;">Không dữ liệu lịch sử
                        mua hàng</p></div>
                </div>
            </div>
    `

function deleteEventModelShow() {
    $('.showModelHistory').html("");
    $('#contacts').css({
        'color': 'rgb(116, 124, 135)',
        'border': 'none'
    })
    $('#debts').css({
        'color': 'rgb(116, 124, 135)',
        'border': 'none'
    })
    $('#histories').css({
        'color': 'rgb(116, 124, 135)',
        'border': 'none'
    })
    $('#notes').css({
        'color': 'rgb(116, 124, 135)',
        'border': 'none'
    })
    $('#addresses').css({
        'color': 'rgb(116, 124, 135)',
        'border': 'none'
    })
    $('#customer_groups').css({
        'color': 'rgb(116, 124, 135)',
        'border': 'none'
    })
}

deleteEventModelShow();

$('#histories').css({
    'color': '#4a8aff',
    'border-bottom': '2px solid rgb(0, 136, 255)'
});
// // Nhóm kahcsh hàng
// $('#customer_groups').click(function () {
//     deleteEventModelShow();
//     $('#customer_groups').css({
//         'color': '#4a8aff',
//         'border-bottom': '2px solid rgb(0, 136, 255)'
//     });
//     $('.showModelHistory').append(modalCustomerGroup)
// });


function getAllProvinces() {
    return $.ajax({
        headers: {
            "accept": "application/json",
            "content-type": "application/json"
        },
        type: "GET",
        url: "https://vapi.vnappmob.com/api/province/"
    })
        .done((data) => {
            if (data.results.length === 0) {
                let str = `<option value="0">Chọn Tỉnh/Thành Phố</option>`;
                $("#province").append(str);
            } else {
                $.each(data.results, (i, item) => {
                    let str = `<option value="${item.province_id}">${item.province_name}</option>`;
                    $("#province").append(str);
                    $('#provinceUpdate').append(str);
                });
            }

        })
        .fail((jqXHR) => {
            console.log(jqXHR);
        })
}

function getAllDistrictsByProvinceId(provinceId) {
    $("#district").empty();
    $("#districtUpdate").empty();
    return $.ajax({
        headers: {
            "accept": "application/json",
            "content-type": "application/json"
        },
        type: "GET",
        url: "https://vapi.vnappmob.com/api/province/district/" + provinceId
    })
        .done((data) => {
            if (data.results.length === 0) {
                let str = `<option value="0">Chọn Quận/Huyện</option>`;
                $("#district").append(str);
            } else {
                $.each(data.results, (i, item) => {
                    let str = ` <option value="${item.district_id}">${item.district_name}</option>`;
                    $("#district").append(str);
                    $('#districtUpdate').append(str);
                })

            }
        })
        .fail((jqXHR) => {
            console.log(jqXHR);
        })
}

function getAllWardsByDistrictId(districtId) {
    $("#ward").empty();
    $('#wardUpdate').empty();
    return $.ajax({
        headers: {
            "accept": "application/json",
            "content-type": "application/json"
        },
        type: "GET",
        url: "https://vapi.vnappmob.com/api/province/ward/" + districtId
    })
        .done((data) => {
            // $('#ward').html('');
            // $('#wardUpdate').html('');

            if (data.results.length === 0) {
                let str = `<option value="0">Chọn Phường/Xã</option>`;
                $("#ward").append(str);

            } else {
                $.each(data.results, (i, item) => {
                    let str = `<option value="${item.ward_id}">${item.ward_name}</option>`;
                    $("#ward").append(str);
                    $('#wardUpdate').append(str);
                });
            }
        })
        .fail((jqXHR) => {
            console.log(jqXHR);
        })
}

getAllProvinces().then(() => {
    let provinceId = $("#province").val();

    getAllDistrictsByProvinceId(provinceId).then(() => {

        let districtId = $("#district").val();

        getAllWardsByDistrictId(districtId);
    });
});
$("#province").on('change', () => {
    let provinceId = $("#province").val();
    getAllDistrictsByProvinceId(provinceId).done(() => {
        let districtId = $("#district").val();
        getAllWardsByDistrictId(districtId);
    })

    $("#district").on('change', () => {
        let districtId = $("#district").val();
        getAllWardsByDistrictId(districtId);
    })
});

$("#provinceUpdate").on("change", () => {
    let provinceId = $("#provinceUpdate").val();
    getAllDistrictsByProvinceId(provinceId).then(() => {
        let districtId = $("#districtUpdate").val();
        getAllWardsByDistrictId(districtId);
    })
})

$("#districtUpdate").on("change", () => {
    let districtId = $("#districtUpdate").val();
    getAllWardsByDistrictId(districtId);
});



<!--    Công nợ-->
$('#debts').click(function () {
    deleteEventModelShow();

    $('#debts').css({
        'color': '#4a8aff',
        'border-bottom': '2px solid rgb(0, 136, 255)'
    });
    $('.showModelHistory').append(modalCongNo)
    showCustomerInfoDebt();
});

//Lịch sừ mua hàng
$('#histories').click(function () {
    deleteEventModelShow();
    $('#histories').css({
        'color': '#4a8aff',
        'border-bottom': '2px solid rgb(0, 136, 255)'
    });

    showCustomerInfoHistory();
});

function showCustomerInfoHistory() {
    let idCustomer = $('.idCustomerDelete').val();
    console.log(idCustomer)
    return $.ajax({
        headers: {
            "accept": "application/json",
            "content-type": "application/json"
        },
        type: "GET",
        url: "http://localhost:8080/api/customers/historyCustomerOrder/" + idCustomer
    })
        .done((data) => {
            console.log(data)
            if (data.length === 0){
                return  $(".showModelHistory").append(noModalHistoryOrder);
            }
            if (0 < data.length){
                $('.showModelHistory').append(modalHistoryOrder)
                return   $.each(data, (i, customer) => {
                    let str = `
                                     <tr class="MuiTableRow-root jss1427 MuiTableRow-hover" role="checkbox"
                                                tabindex="-1">
                                                <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignLeft">
                                                    <a class="jss1437" href="/admin/orders/1167549753">${customer.order_code}</a>
                                                </td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignLeft">
                                                    <div class="sc-jSMfEi hBmWYo"><span class="${customer.status === 'Đang giao dịch' ? 'sc-eCYdqJ bzQjtT text-success' : 'sc-eCYdqJ bzQjtT text-warning'}">${customer.status}</span>
                                                    </div>
                                                </td>

                                                <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignRight">
                                                    <p class="MuiTypography-root MuiTypography-body1"
                                                       >
                                                       ${customer.grand_total != null ? (new Intl.NumberFormat('vi-VN', {
                        style: 'currency',
                        currency: 'VND'
                    }).format(customer.grand_total)) : "---"}
                                                       </p></td>

                                                <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignLeft">
                                                    <p class="MuiTypography-root MuiTypography-body1"
                                                       >Chi nhánh mặc định</p></td>
                                                         <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignLeft">
                                                <p class="MuiTypography-root MuiTypography-body1"
                                                       >${customer.debt != null ? (new Intl.NumberFormat('vi-VN', {
                        style: 'currency',
                        currency: 'VND'
                    }).format(customer.debt)) : "---"}</p></td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignLeft">
                                                    <p class="MuiTypography-root MuiTypography-body1" title="Pos">
                                                        Web</p></td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignLeft">
                                                    <p class="MuiTypography-root MuiTypography-body1"
                                                       title="">${customer.employee_name}</p></td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss1433 MuiTableCell-alignLeft">
                                                    <div>
                                                    ${customer.create_at != null ? moment(customer.create_at).format('DD/MM/yyyy hh:ss') : "---"}
                                                    </div>
                                                </td>
                                            </tr>
                                   `
                    $(".showAllCustomerOrderHistory").append(str);
                });
                $('#tableHistoryCustomerOrder').DataTable();

            }
        })
        .fail((jqXHR) => {

        })
}




// Công nợ
function showCustomerInfoDebt() {
    let idCustomer = $('.idCustomerDelete').val();
    console.log(idCustomer)
    return $.ajax({
        headers: {
            "accept": "application/json",
            "content-type": "application/json"
        },
        type: "GET",
        url: "http://localhost:8080/api/customers/customerDebt/" + idCustomer
    })
        .done((data) => {
            console.log(data)
            $.each(data, (i, order) => {
                let str = `
                   <tr class="MuiTableRow-root jss910 MuiTableRow-hover" role="checkbox"
                                                tabindex="-1">
                                                <td class="MuiTableCell-root MuiTableCell-body jss916 MuiTableCell-alignLeft">
                                                    <a class="jss920" target="_blank"
                                                       href="/admin/receipt_vouchers/296331927/edit">${order.order_code}</a></td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss916 MuiTableCell-alignLeft">
                                                    <span>${order.employee_name}</td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss916 MuiTableCell-alignLeft">
                                                    <span>
                                                        ${order.create_at != null ? moment(order.create_at).format('DD/MM/yyyy hh:ss') : "---"}</td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss916 MuiTableCell-alignLeft">
                                                    <span>
                                                         ${order.create_at != null ? moment(order.create_at).format('DD/MM/yyyy hh:ss') : "---"}</td>
                                                    </span></td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss916 MuiTableCell-alignLeft">
                                                    <span>${order.description}</span></td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss916 MuiTableCell-alignRight">
                                                    <span style="padding: 16px;">
                                                                   ${order.transaction != null ? (new Intl.NumberFormat('vi-VN', {
                    style: 'currency',
                    currency: 'VND'
                }).format(order.transaction)) : "---"}</span></td>
                                                <td class="MuiTableCell-root MuiTableCell-body jss916 MuiTableCell-alignRight">
                                                    <span style="padding: 16px;"> ${order.total_transaction != null ? (new Intl.NumberFormat('vi-VN', {
                    style: 'currency',
                    currency: 'VND'
                }).format(order.total_transaction)) : "---"}</span></td>
                                                    </tr>
                                        `
                $(".showCustomerDebtById").prepend(str);
            });
        })
        .fail((jqXHR) => {

        })
}





